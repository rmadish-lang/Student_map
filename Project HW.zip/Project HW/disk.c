#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PAGE_TABLE_SIZE 256
#define PAGE_SIZE 256
#define FRAME_COUNT 256
#define FRAME_SIZE 256

// Bit mask for masking out lower 8 bits(0-7)
#define MASK_FRAME_NUMBER 0x000000FF
// Bit mask for masking out bits 8-15
#define MASK_PAGE_NUMBER 0x0000FF00
// macro to extract bits 8-15 from a number, then shift right by 8 bits
#define get_page_num(num) ((num & MASK_PAGE_NUMBER) >> 8)
// macro to extract bits 0-15 from anumber
#define get_frame_offset(num) (num & MASK_FRAME_NUMBER)

#define TLBSIZE 16

// Define a page table entry struct
struct PageTableEntry
{
    // bool valid; // Whether the page is currently in physical memory
    int frame_number; // The physical memory frame number that contains the page
    int page_number;
};

// array of PageTableEntry to make up page table
struct PageTableEntry page_table[PAGE_TABLE_SIZE];

struct FRAME
{
    signed char data[FRAME_SIZE];
    int last_accessed;
};

// Frame # --> Frame data
struct FRAME physical_memory[FRAME_COUNT];

struct TLBEntry
{
    int page_number;
    int frame_number;
    int last_accessed;
};

struct TLBEntry tlb[TLBSIZE];

int availableFrameIndex = 0;
int availablePageTableIndex = 0;

int main()
{

    // if(argc!=3){
    //     printf("Error invalid arguments");
    // }

    // address translation variables
    unsigned int logical_address;
    int frame_offset;
    int page_number;

    // date read from physical memory , must be signed type
    signed char data_read;

    char *address_text_filename;
    char *backing_store_filename;

    // static variables
    int page_fault = 0;
    int tlb_hits = 0;
    int num_addresses_translated = 0;

    // address_text_filename = argv[1];
    // backing_store_filename = argv[2];

    // init physical memory
    for (int i = 0; i < FRAME_COUNT; i++)
    {
        memset(physical_memory[i].data, 0, FRAME_SIZE);
        physical_memory[i].last_accessed = -1;
    }

    // init page table
    for (int i = 0; i < PAGE_TABLE_SIZE; i++)
    {
        page_table[i].page_number = -1;
        page_table[i].frame_number = -1;
    }

    // init tlb
    for (int i = 0; i < TLBSIZE; i++)
    {
        tlb[i].page_number = -1;
        tlb[i].frame_number = -1;
        tlb[i].last_accessed = -1;
    }

    FILE *address_to_translate = fopen("addresses.txt", "r");
    if (address_to_translate == NULL)
    {
        perror("Could not open addresses file");
        exit(-2);
    }

    FILE *backing_store_file = fopen("BACKING_STORE.bin", "rb");
    if (backing_store_file == NULL)
    {
        perror("Could not open backing file");
        exit(-2);
    }

    while (fscanf(address_to_translate, "%d\n", &logical_address) == 1)
    {
        num_addresses_translated++;
        page_number = get_page_num(logical_address);
        frame_offset = get_frame_offset(logical_address);

        printf("Virtual address: %5d, Page Number: %3d, Frame Offset: %3d\n", logical_address, page_number, frame_offset);

        // printf("Virtual address: %5d, Physical Address: %5d, Value: %5d\n", logical_address, (physical_address <<8)}| frame_offset, data_read);
    }
    float hit_rate = (float)tlb_hits / num_addresses_translated;
    float fault_rate = (float)page_fault / num_addresses_translated;
    printf("Hit Rate: %0.2f\n  Page Fault Rate: %0.2f\n", hit_rate, fault_rate);
    fclose(address_to_translate);
    fclose(backing_store_file);
}

// // Declare functions
// void initialize_physical_memory(struct PhysicalMemory* mem);
// void initialize_page_table(struct PageTable* table);
// int translate_virtual_address(int address, struct PageTable* table);
// void load_page_into_memory(int page_number, struct PhysicalMemory* mem, struct PageTable* table);

// // Main function
// int main() {
//     // Initialize the physical memory and page table
//     struct PhysicalMemory memory;
//     struct PageTable page_table;
//     initialize_physical_memory(&memory);
//     initialize_page_table(&page_table);

//     // Example usage: translate a virtual address and load a page into physical memory
//     int virtual_address = 0x00000001;
//     int physical_address = translate_virtual_address(virtual_address, &page_table);
//     load_page_into_memory(physical_address / PAGE_SIZE, &memory, &page_table);

//     return 0;
// }

// // Initialize the physical memory
// void initialize_physical_memory(struct PhysicalMemory* mem) {
//     for (int i = 0; i < NUM_PAGES; i++) {
//         mem->free_frames[i] = true;
//     }
// }

// // Initialize the page table
// void initialize_page_table(struct PageTable* table) {
//     for (int i = 0; i < NUM_PAGES; i++) {
//         table->entries[i].valid = false;
//         table->entries[i].frame = -1;
//     }
// }

// // Translate a virtual address to a physical address using the page table
// int translate_virtual_address(int address, struct PageTable* table) {
//     int page_number = address / PAGE_SIZE;
//     if (!table->entries[page_number].valid) {
//         // Page fault - the page is not currently in physical memory
//         // Load the page into physical memory
//         //load_page_into_memory(page_number, &memory, table);
//     }
//     int frame_number = table->entries[page_number].frame;
//     int offset = address % PAGE_SIZE;
//     return frame_number * PAGE_SIZE + offset;
// }

// // Load a page into physical memory
// void load_page_into_memory(int page_number, struct PhysicalMemory* mem, struct PageTable* table) {
//     // Find a free frame in physical memory
//     int frame_number;
//     for (int i = 0; i < NUM_PAGES; i++) {
//         if (mem->free_frames[i]) {
//             frame_number = i;
//             mem->free_frames[i] = false;
//             break;
//         }
//     }
// }
// // Copy the page from disk into physical memory
// // ...

// // Update the page table entry for the page
// //table->entries[page_number].valid = true;
// //table->entries[page_number].frame = frame_number;

// //write a C program that translates logical to physical addresses for a virtual address space of
// //65,536 bytes. The program will read a file consisting logical addresses and, using a TLB as
// //well a page table, will translate each logical address to its corresponding physical address
// //and the output of the byte stored at the translated physical address.
// //write a simple program that extracts the page number and offset from following
// //integers- 1,256,32768,32769,128,65534,33153 by using operators for bit-masking and bit-shifting

// // Example function to translate a virtual address to a physical address and load a page into physical memory
// int translate_and_load(int virtual_address, struct PageTableEntry* page_table, struct PhysicalMemory* physical_memory) {
//     int page_number = virtual_address / 4096; // Assuming a page size of 4KB
//     if (!page_table[page_number].valid) {
//         // Page fault - the page is not currently in physical memory
//         // Select a physical memory frame to evict using a page replacement algorithm
//         // For simplicity, we'll just select the first free frame
//         int frame_number;
//         for (int i = 0; i < 1024; i++) {
//             if (physical_memory->free_frames[i]) {
//                 frame_number = i;
//                 physical_memory->free_frames[i] = false;
//                 break;
//             }
//         }
//         // Load the page from disk into physical memory
//         // For simplicity, we'll just assume the page is stored in a file with the same name as the process
//         char filename[256];
//         sprintf(filename, "%d", getpid()); // Assume the process ID is the filename
//         FILE* file = fopen(filename, "r");
//         fseek(file, page_number * 4096, SEEK_SET);
//         fread(&physical_memory->memory[frame_number * 4096], 1, 4096, file);
//         fclose(file);
//         // Update the page table entry for the page
//         page_table[page_number].valid = true;
//         page_table[page_number].frame = frame_number;
//     }
//     // Translate the virtual address to a physical address using the page table
//     int offset = virtual_address % 4096;
//     int physical_address = page_table[page_number].frame * 4096 + offset;

// // Print out the logical address, physical address, and byte value at the physical address
//     printf("Logical address: %d\n", virtual_address);
//     printf("Physical address: %d\n", physical_address);
//     printf("Byte value at physical address: %d\n", physical_memory->memory[physical_address]);

// return physical_address;